// popular (load more)


$(function(){
    $('#popular-wrap-popular .product-card').slice(0, 8).show();
    $('#load-more').on('click', function(e){
        e.preventDefault();
        $('#popular-wrap-popular .product-card:hidden').slice(0, 8).slideDown();
        if ($('.product-card:hidden').length == 0) {$('#load-more').hide()}
    });
});
